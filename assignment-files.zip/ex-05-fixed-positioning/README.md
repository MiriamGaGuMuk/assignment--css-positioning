#Sample Layout Mockup

![nike flexband layout](./mockups/nike-flexband-layout.png)


### Landing Page - Copywriting 
```

Client: Nike +
Project: Fuel Band

Life is a sport. Make it count.

Two years ago Nike came to us to realize an idea: a device that tracks your daily activity and a common universal metric called Fuel for every active body out there. They asked us to design the entire user experience. We ensured ease of use: set your goal, animations celebrate your performance. Hit a streak and Fuelie shows up to cheer you on. Data visualization show where you were most active daily, weekly, monthly, and beyond. We created Bluetooth synch technology so when you finish your day, your Fuel is wireless synced to the platform. NikeFuel levels the playing field, and fits into your life. #Counts


=====
The Fuel Band tracks all of your activity
Click to enlarge

Bluetooth sync technology uploads data seamlessly
Click to enlarge.

Hitting your daily Fuel goal keeps you motivated
Click to enlarge.
```